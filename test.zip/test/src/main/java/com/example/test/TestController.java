package com.example.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/test")
@Api(tags = "Test Controller")
@CrossOrigin
public class TestController {
    
    @Autowired
    CallMeService callMe;

	@GetMapping(value = "/get")
	@ApiOperation("Get Request")
	public ResponseEntity<String> sayHelloGet() {
		String str = "Hello Get !!";		
		ResponseEntity<String> res = new ResponseEntity<String>(str, HttpStatus.OK);
		return res;
	}
	
	@PostMapping(value = "/post")
	@ApiOperation("Post Request")
	public ResponseEntity<String> sayHelloPost() {	
		String str = "Hello Post !!";		
		ResponseEntity<String> res = new ResponseEntity<String>(str, HttpStatus.OK);
		return res;
	}
	
	@GetMapping(value = "/get/feign")
    @ApiOperation("Get Request")
    public ResponseEntity<String> callGetWithFeign() {
        String str = callMe.callGetWithFeign();        
        ResponseEntity<String> res = new ResponseEntity<String>(str, HttpStatus.OK);
        return res;
    }
    
    @PostMapping(value = "/post/feign")
    @ApiOperation("Post Request")
    public ResponseEntity<String> callPostWithFeign() {  
        String str = callMe.callPostWithFeign();       
        ResponseEntity<String> res = new ResponseEntity<String>(str, HttpStatus.OK);
        return res;
    }
    
    @PostMapping(value = "/postwithoutbody/feign/{content}")
    @ApiOperation("Post Request")
    public ResponseEntity<String> callPostWihtoutBodyWithFeign(@PathVariable String content) {  
        String str = callMe.callPostWihtoutBodyWithFeign(content);       
        ResponseEntity<String> res = new ResponseEntity<String>(str, HttpStatus.OK);
        return res;
    }
}
