package com.example.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CallMeService {

    @Autowired
    CallMeAccessor callMe;

    public String callGetWithFeign() {
        return callMe.callMeGet().getBody();
    }

    public String callPostWithFeign() {
        return callMe.callMePOST().getBody();

    }

    public String callPostWihtoutBodyWithFeign(String content) {
        return callMe.callMePOSTWithOutBody(content).getBody();
    }

}
