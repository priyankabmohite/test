package com.example.test;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "callme", url = "${callme.url}")
public interface CallMeAccessor {

    @RequestMapping(value = "/call/get", method = RequestMethod.GET)
    ResponseEntity<String> callMeGet();
    
    @RequestMapping(value = "/call/post", method = RequestMethod.POST)
    ResponseEntity<String> callMePOST();
    
    @RequestMapping(value = "/call/postwithoutbody/{id}", method = POST)
    ResponseEntity<String> callMePOSTWithOutBody(@PathVariable("id") final String id);

}
