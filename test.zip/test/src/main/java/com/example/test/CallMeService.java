package com.example.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CallMeService {
    
    @Value("${callme.url}")
    private String url;

    @Autowired
    CallMeAccessor callMe;

    public String callGetWithFeign() {
        return callMe.callMeGet().getBody();
    }

    public String callPostWithFeign() {
        return callMe.callMePOST().getBody();

    }

    public String callPostWihtoutBodyWithFeign(String content) {
        return callMe.callMePOSTWithOutBody(content).getBody();
    }
    
    public String callPostWihtBodyWithFeign(TestBody content) {
        return callMe.callMePOSTWithBody(content).getBody();
    }

    public String callPostWithRest() {
        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.postForEntity(url + "/call/post", null, String.class).getBody();
        return result;
    }

}
